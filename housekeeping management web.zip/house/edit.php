<?php
require_once('process/dbh.php'); // Include your database connection file.

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch the user information based on the provided ID using a prepared statement
    $sql = "SELECT * FROM userinfo WHERE bio_id = ?";
    
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    
    $result = mysqli_stmt_get_result($stmt);

    if (!$result) {
        die("Error: " . mysqli_error($conn));
    }

    $userinfo = mysqli_fetch_assoc($result);

    // Check if the form has been submitted
    if (isset($_POST['submit'])) {
        // Retrieve and sanitize the updated data from the form
        $updatedFirstName = mysqli_real_escape_string($conn, $_POST['firstName']);
        $updatedLastName = mysqli_real_escape_string($conn, $_POST['lastName']);
        $updatedEmail = mysqli_real_escape_string($conn, $_POST['email']);
        $updatedContact = mysqli_real_escape_string($conn, $_POST['contact']);
        $updatedDesignation = mysqli_real_escape_string($conn, $_POST['Designation']);
        $updatedQualification = mysqli_real_escape_string($conn, $_POST['qualification']);

        // Update the user information in the database using a prepared statement
        $updateSql = "UPDATE userinfo SET firstName=?, lastName=?, email=?, contact=?, Designation=?, qualification=? WHERE bio_id=?";
        
        $stmt = mysqli_prepare($conn, $updateSql);
        mysqli_stmt_bind_param($stmt, "ssssssi", $updatedFirstName, $updatedLastName, $updatedEmail, $updatedContact, $updatedDesignation, $updatedQualification, $id);
        
        if (mysqli_stmt_execute($stmt)) {
            header("Location: aloginwel.php"); // Redirect to the desired page after successful update
            exit();
        } else {
            die("Error updating record: " . mysqli_error($conn));
        }
    }
} else {
    die("Invalid ID");
}
?>

<!-- HTML form to edit user information -->
<html>
<head>

    <style>
        header{
        background-color:#005690;
    
    }
    .divider {
    background-color: #8BCA02;
    height: 5px;
}
        </style>
</head>
<body>
    <h2>Edit User Information</h2>
    <form method="POST">
        <label for="firstName">First Name:</label>
        <input type="text" name="firstName" value="<?php echo $userinfo['firstName']; ?>" required><br>
        <label for="lastName">First Name:</label>
        <input type="text" name="lastName" value="<?php echo $userinfo['lastName']; ?>" required><br>
        <label for="email">First Name:</label>
        <input type="email" name="email" value="<?php echo $userinfo['email']; ?>" required><br>
        <label for="contact">First Name:</label>
        <input type="text" name="contact" value="<?php echo $userinfo['contact']; ?>" required><br>
        <label for="Designation">Designation:</label>
        <input type="text" name="Designation" value="<?php echo $userinfo['Designation']; ?>" required><br>

        <label for="qualification">Qualification:</label>
        <input type="text" name="qualification" value="<?php echo $userinfo['qualification']; ?>" required><br>

        <input type="submit" name="submit" value="Update">
    </form>
</body>
</html>
