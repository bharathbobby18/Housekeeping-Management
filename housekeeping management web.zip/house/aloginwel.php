<?php
require_once('process/dbh.php');
$sql = "SELECT bio_id, firstName, lastName, email, contact, Designation, qualification FROM userinfo";
$result = mysqli_query($conn, $sql);
if (!$result) {
    die("Error: " . mysqli_error($conn));
}
?>
<html>
<head>
	<title>Admin Panel | housekeeping Management System</title>
	<link rel="stylesheet" type="text/css" href="styleemplogin.css">
	<style>
		
			.container {
    background-color:#005690;
}
.logo {
    font-size: 2em;
    color: #fff;
    user-select: none;
}

header h1 {
    display: inline;
    font-family:Poppins, sans-serif;
    font-weight: 400;
    font-size: 32px;
    float: left;
    margin-top: 0px;
    margin-right: 10px;
}
.homered {
    background-color: #005690;
    padding: 30px 10px 20px 10px;
}

  .divider{
	background-color: rgb(0, 86, 144);
	height: 5px;
  }
  
  .homeblack:hover{
	background-color: rgb(0 86 144);
	padding: 30px 10px 18px 10px;
  
  }


  header {
    background: #005690;
    color: white;
    padding: 18px 20px 53px 40px;
    height: 4px;
}

		.divider {
    background-color: #8BCA02;
    height: 5px;
}
nav ul li a {
    color: #00000;
    text-decoration: none;
}
	</style>
</head>
<body>
	
	<header>
		<nav>
			<h1><h1 class="container">Housekeeping Management</h1>
			<ul id="navli">
				<li><a class="homered" href="aloginwel.php">HOME</a></li>
				<li><a class="homeblack" href="addemp.php">add employee</a></li>
				<li><a class="homeblack" href="building.php">manage buildings</a></li>
				<li><a class="homeblack" href="login.html">Log Out</a></li>
			</ul>
		</nav>
	</header>
	<div class="divider"></div>

		<table>
			<tr>

				<th align = "center">bio_id</th>
				<th align = "center">firstName</th>
				<th align = "center">lastname</th>
				<th align = "center">email</th>
				<th align = "center">contact</th>
				<th align = "center">Designation</th>
				<th align = "center">qualification</th>
				<th align = "center">Options</th>
			</tr>

			<?php
				while ($userinfo = mysqli_fetch_assoc($result)) {
					echo "<tr>";
					echo "<td>".$userinfo['bio_id']."</td>";
					echo "<td>".$userinfo['firstName']."</td>";
					echo "<td>".$userinfo['lastName']."</td>";
					echo "<td>".$userinfo['email']."</td>";
					echo "<td>".$userinfo['contact']."</td>";
					echo "<td>".$userinfo['Designation']."</td>";
					echo "<td>".$userinfo['qualification']."</td>";
					echo "<td><a href=\"delete.php?bio_id={$userinfo['bio_id']}\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";

				}


			?>

		</table>
		
	
</body>
</html>
	 
	